from llama_index.readers.file.image_caption.base import ImageCaptionReader

__all__ = ["ImageCaptionReader"]
