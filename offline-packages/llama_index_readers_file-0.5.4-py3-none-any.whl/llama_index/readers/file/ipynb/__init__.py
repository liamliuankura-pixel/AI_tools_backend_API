from llama_index.readers.file.ipynb.base import IPYNBReader

__all__ = ["IPYNBReader"]
