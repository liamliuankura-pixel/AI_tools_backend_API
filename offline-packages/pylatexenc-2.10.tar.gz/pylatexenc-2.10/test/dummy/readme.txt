This directory is just used as base '\input{}' directory, to test the strict_input flag of LatexNodes2Text.
